# Tab Apple

## 1.0.0

[x] 등장 소멸 애니메이션 모듈

[x] 아이콘 component
   [x] hover하면 살짝 커지는 animation

[x] 3가지 선택 (favorites, recent pages, picked favorites)

[x] 넘기는 animation 모듈

[x] live background 모듈

[x] chrome newtab favicon, title

[x] worker 는 수정이 필요함 (더 간단한 로직으로, 그냥 저장만 해야함)

## 1.1.0

[x] full-width 일 때 stylechildren, wheel 오류